<?php
/**
 * Layout Meta Options
 * Controls per-page visibility of Header, Footer, Sidebar.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// 1. Register Meta Box
add_action( 'add_meta_boxes', 'techsup_add_layout_meta' );
function techsup_add_layout_meta() {
    $screens = [ 'post', 'page' ];
    foreach ( $screens as $screen ) {
        add_meta_box(
            'techsup_layout_options',
            __( 'Page Layout Controls', 'techsup-theme' ),
            'techsup_render_layout_meta',
            $screen,
            'side'
        );
    }
}

// 2. Render UI
function techsup_render_layout_meta( $post ) {
    wp_nonce_field( 'techsup_save_layout_meta', 'techsup_layout_nonce' );
    
    $disable_header  = get_post_meta( $post->ID, '_techsup_disable_header', true );
    $disable_footer  = get_post_meta( $post->ID, '_techsup_disable_footer', true );
    $disable_sidebar = get_post_meta( $post->ID, '_techsup_disable_sidebar', true );
    $transparent     = get_post_meta( $post->ID, '_techsup_transparent_header', true );
    ?>
    <div class="techsup-meta-options">
        <p>
            <label>
                <input type="checkbox" name="techsup_disable_header" value="1" <?php checked( $disable_header, 1 ); ?> />
                <?php esc_html_e( 'Disable Header', 'techsup-theme' ); ?>
            </label>
        </p>
        <p>
            <label>
                <input type="checkbox" name="techsup_disable_footer" value="1" <?php checked( $disable_footer, 1 ); ?> />
                <?php esc_html_e( 'Disable Footer', 'techsup-theme' ); ?>
            </label>
        </p>
        <p>
            <label>
                <input type="checkbox" name="techsup_disable_sidebar" value="1" <?php checked( $disable_sidebar, 1 ); ?> />
                <?php esc_html_e( 'Force Full Width (No Sidebar)', 'techsup-theme' ); ?>
            </label>
        </p>
        <hr>
        <p>
            <label>
                <input type="checkbox" name="techsup_transparent_header" value="1" <?php checked( $transparent, 1 ); ?> />
                <?php esc_html_e( 'Transparent Header (Merge)', 'techsup-theme' ); ?>
            </label>
        </p>
    </div>
    <?php
}

// 3. Save Data
add_action( 'save_post', 'techsup_save_layout_meta' );
function techsup_save_layout_meta( $post_id ) {
    if ( ! isset( $_POST['techsup_layout_nonce'] ) || ! wp_verify_nonce( $_POST['techsup_layout_nonce'], 'techsup_save_layout_meta' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
    if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

    $keys = [ 'techsup_disable_header', 'techsup_disable_footer', 'techsup_disable_sidebar', 'techsup_transparent_header' ];
    foreach ( $keys as $key ) {
        $meta_key = '_' . $key;
        if ( isset( $_POST[ $key ] ) ) {
            update_post_meta( $post_id, $meta_key, 1 );
        } else {
            delete_post_meta( $post_id, $meta_key );
        }
    }
}