<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Check if sidebar should be displayed
 */
function techsup_has_sidebar() {
    // 1. Meta Box Override (Full Width)
    if ( is_singular() ) {
        if ( get_post_meta( get_the_ID(), '_techsup_disable_sidebar', true ) ) {
            return false;
        }
    }
    // 2. Default Logic
    return is_active_sidebar( 'sidebar-1' );
}

/**
 * Add Transparency Class to Body
 */
add_filter( 'body_class', 'techsup_body_classes' );
function techsup_body_classes( $classes ) {
    // Add transparent class if meta is checked
    if ( is_singular() && get_post_meta( get_the_ID(), '_techsup_transparent_header', true ) ) {
        $classes[] = 'transparent-header-enabled';
    }
    return $classes;
}