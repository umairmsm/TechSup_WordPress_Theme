<?php
/**
 * Customizer Logic
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'customize_register', 'techsup_customize_register' );
function techsup_customize_register( $wp_customize ) {
    // Section: Layout
    $wp_customize->add_section( 'techsup_layout', array(
        'title' => __( 'Layout', 'techsup-theme' ),
        'priority' => 30,
    ));

    // Container Width
    $wp_customize->add_setting( 'techsup_container_width', array(
        'default' => 1200,
        'sanitize_callback' => 'absint',
        'transport' => 'postMessage',
    ));
    $wp_customize->add_control( 'techsup_container_width', array(
        'label' => __( 'Container Width (px)', 'techsup-theme' ),
        'section' => 'techsup_layout',
        'type' => 'number',
    ));

    // Section: Colors (Using Built-in 'colors')
    $wp_customize->add_setting( 'techsup_primary_color', array(
        'default' => '#0073aa',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage',
    ));
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'techsup_primary_color', array(
        'label' => __( 'Primary Color', 'techsup-theme' ),
        'section' => 'colors',
    )));
}

// Output CSS Variables
add_action( 'wp_head', 'techsup_customizer_css' );
function techsup_customizer_css() {
    $width = get_theme_mod( 'techsup_container_width', 1200 );
    $color = get_theme_mod( 'techsup_primary_color', '#0073aa' );
    ?>
    <style>
        :root {
            --container-width: <?php echo absint( $width ); ?>px;
            --color-primary: <?php echo esc_attr( $color ); ?>;
        }
    </style>
    <?php
}