<?php
/**
 * Block Elements System
 * "The Elementor Killer" - Inject Gutenberg blocks into hooks.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// 1. Register CPT
add_action( 'init', 'techsup_register_elements_cpt' );
function techsup_register_elements_cpt() {
    register_post_type( 'techsup_element', array(
        'labels' => array( 'name' => 'Elements', 'singular_name' => 'Element' ),
        'public' => false,
        'show_ui' => true,
        'supports' => array( 'title', 'editor' ),
        'show_in_rest' => true, // Gutenberg Support
        'menu_icon' => 'dashicons-layout',
    ));
}

// 2. Meta Box for Hook Location
add_action( 'add_meta_boxes', 'techsup_element_meta_box' );
function techsup_element_meta_box() {
    add_meta_box( 'techsup_element_settings', 'Hook Location', 'techsup_element_meta_render', 'techsup_element', 'side' );
}

function techsup_element_meta_render( $post ) {
    wp_nonce_field( 'techsup_element_save', 'techsup_element_nonce' );
    $location = get_post_meta( $post->ID, '_techsup_element_location', true );
    
    $hooks = array(
        'techsup_before_header' => 'Before Header (Top Bar)',
        'techsup_after_header' => 'After Header (Hero Section)',
        'techsup_before_content' => 'Before Content',
        'techsup_after_content' => 'After Content',
        'techsup_before_footer' => 'Before Footer (CTA)',
        'techsup_after_footer' => 'After Footer (Scripts)',
    );
    ?>
    <select name="techsup_element_location" style="width:100%">
        <option value="">-- Select Location --</option>
        <?php foreach( $hooks as $hook => $label ) : ?>
            <option value="<?php echo esc_attr( $hook ); ?>" <?php selected( $location, $hook ); ?>><?php echo esc_html( $label ); ?></option>
        <?php endforeach; ?>
    </select>
    <?php
}

add_action( 'save_post', 'techsup_element_save' );
function techsup_element_save( $post_id ) {
    if ( ! isset( $_POST['techsup_element_nonce'] ) || ! wp_verify_nonce( $_POST['techsup_element_nonce'], 'techsup_element_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    
    if ( isset( $_POST['techsup_element_location'] ) ) {
        update_post_meta( $post_id, '_techsup_element_location', sanitize_text_field( $_POST['techsup_element_location'] ) );
    }
}

// 3. The Injection Engine
// Automatically hook into all defined locations
add_action( 'wp', 'techsup_initialize_elements' );
function techsup_initialize_elements() {
    // List of supported hooks to check
    $hooks = [ 'techsup_before_header', 'techsup_after_header', 'techsup_before_content', 'techsup_after_content', 'techsup_before_footer', 'techsup_after_footer' ];
    
    foreach ( $hooks as $hook ) {
        add_action( $hook, function() use ( $hook ) {
            techsup_render_elements( $hook );
        });
    }
}

function techsup_render_elements( $hook_name ) {
    // Query for elements assigned to this hook
    $args = array(
        'post_type' => 'techsup_element',
        'posts_per_page' => -1,
        'meta_key' => '_techsup_element_location',
        'meta_value' => $hook_name,
    );

    $query = new WP_Query( $args );

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            echo '<div class="techsup-element element-' . get_the_ID() . '">';
            the_content();
            echo '</div>';
        }
        wp_reset_postdata();
    }
}