<?php
/**
 * Core Hook System
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// --- 1. Define the Trigger Functions ---
function techsup_before_header() { do_action( 'techsup_before_header' ); }
function techsup_header() { do_action( 'techsup_header' ); }
function techsup_after_header() { do_action( 'techsup_after_header' ); }

function techsup_before_content() { do_action( 'techsup_before_content' ); }
function techsup_after_content() { do_action( 'techsup_after_content' ); }

function techsup_before_footer() { do_action( 'techsup_before_footer' ); }
function techsup_footer() { do_action( 'techsup_footer' ); }
function techsup_after_footer() { do_action( 'techsup_after_footer' ); }

// --- 2. Attach Default Content to Hooks ---

// Header Structure
add_action( 'techsup_header', 'techsup_header_content', 10 );
function techsup_header_content() {
    ?>
    <div class="techsup-container">
        <div class="techsup-header-inner">
            <div class="site-branding">
                <?php
                if ( has_custom_logo() ) {
                    the_custom_logo();
                } else {
                    echo '<h1 class="site-title"><a href="' . esc_url( home_url( '/' ) ) . '">' . get_bloginfo( 'name' ) . '</a></h1>';
                }
                ?>
            </div>

            <nav id="site-navigation" class="main-navigation">
                <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
                    <?php esc_html_e( 'Menu', 'techsup-theme' ); ?>
                </button>
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_id'        => 'primary-menu',
                    'container'      => false,
                    'fallback_cb'    => false, // Do not show page list if no menu assigned
                ) );
                ?>
            </nav>
        </div>
    </div>
    <?php
}

// Footer Structure
add_action( 'techsup_footer', 'techsup_footer_content', 10 );
function techsup_footer_content() {
    ?>
    <div class="techsup-container">
        <div class="techsup-copyright">
            &copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>.
        </div>
    </div>
    <?php
}