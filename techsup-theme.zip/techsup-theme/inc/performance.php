<?php
/**
 * Performance Tweaks
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', 'techsup_cleanup_head' );
function techsup_cleanup_head() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'wp_head', 'wp_generator' ); // Security
    remove_action( 'wp_head', 'wlwmanifest_link' );
}

// Defer Navigation JS
add_filter( 'script_loader_tag', 'techsup_defer_scripts', 10, 3 );
function techsup_defer_scripts( $tag, $handle, $src ) {
    if ( 'techsup-nav' === $handle ) {
        return str_replace( ' src', ' defer src', $tag );
    }
    return $tag;
}